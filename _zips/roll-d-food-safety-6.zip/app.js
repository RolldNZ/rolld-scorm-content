(function(){
  var screens=[].slice.call(document.querySelectorAll(".screen"));
  var navBtns=[].slice.call(document.querySelectorAll("nav button[data-go]"));
  var statusPill=document.getElementById("statusPill");
  var current=0, started=false, score=null;

  function setStatus(t){ statusPill.textContent=t; }
  function show(i){
    current=Math.max(0,Math.min(screens.length-1,i));
    screens.forEach(function(s){ s.hidden = (Number(s.dataset.screen)!==current); });
    navBtns.forEach(function(b){ b.classList.toggle("active", Number(b.dataset.go)===current); });
    if(started && SCORM.initialized){ SCORM.set("cmi.core.lesson_location", String(current)); SCORM.commit(); }
    window.scrollTo(0,0);
  }
  function start(){
    if(started) return;
    started=true; setStatus("In progress");
    if(SCORM.initialized){ SCORM.set("cmi.core.lesson_status","incomplete"); SCORM.commit(); }
  }

  navBtns.forEach(function(b){
    b.addEventListener("click", function(){
      start(); show(Number(b.dataset.go));
    });
  });
  document.getElementById("startBtn").addEventListener("click", function(){ start(); show(1); });

  [].slice.call(document.querySelectorAll("[data-next]")).forEach(function(b){
    b.addEventListener("click", function(){ start(); show(current+1); });
  });
  [].slice.call(document.querySelectorAll("[data-prev]")).forEach(function(b){
    b.addEventListener("click", function(){ start(); show(current-1); });
  });

  // Quiz
  var questions=[
    {q:"Minimum safe rice holding temperature during service?", a:["50C","60C or above","Below 5C","75C for 30 seconds"], c:1},
    {q:"How often must rice be checked while holding?", a:["Every 30 minutes","Every 1 hour","Every 2 hours","Once per shift"], c:2},
    {q:"All poultry must be cooked to:", a:["65C for 15 seconds","70C for 2 minutes","75C for 30 seconds","80C instantly"], c:2},
    {q:"When must poultry be tested?", a:["First batch only","After each batch","Weekly only","Only if it looks undercooked"], c:1},
    {q:"How often must the proven method be verified and recorded?", a:["Daily","Weekly","Monthly","Only at audits"], c:1}
  ];
  function renderQuiz(){
    var form=document.getElementById("quiz");
    form.innerHTML=questions.map(function(qq,i){
      var opts=qq.a.map(function(opt,j){
        return '<label style="display:block;margin:8px 0"><input type="radio" name="q'+i+'" value="'+j+'"> '+opt+'</label>';
      }).join("");
      return '<div style="margin:10px 0"><b>'+(i+1)+". "+qq.q+'</b>'+opts+'</div>';
    }).join("");
  }
  function grade(){
    var correct=0;
    questions.forEach(function(qq,i){
      var chosen=document.querySelector('input[name="q'+i+'"]:checked');
      var val=chosen?Number(chosen.value):-1;
      if(val===qq.c) correct++;
    });
    score=Math.round((correct/questions.length)*100);
    var pass=score>=80;

    var res=document.getElementById("quizResult");
    res.className="result "+(pass?"ok":"bad");
    res.style.display="block";
    res.innerHTML= pass ? "<b>Pass</b> - Score: "+score+"%. Continue to Finish." : "<b>Not yet</b> - Score: "+score+"%. Review and try again.";

    if(SCORM.initialized){
      SCORM.set("cmi.core.score.raw", String(score));
      SCORM.set("cmi.core.lesson_status", pass ? "passed" : "incomplete");
      SCORM.commit();
    }
    setStatus(pass ? "Passed" : "In progress");
    if(pass) show(6);
  }

  document.getElementById("submitQuiz").addEventListener("click", function(){ start(); grade(); });

  document.getElementById("finishBtn").addEventListener("click", function(){
    start();
    var pass = (typeof score==="number" && score>=80);
    if(SCORM.initialized){
      if(typeof score==="number") SCORM.set("cmi.core.score.raw", String(score));
      SCORM.set("cmi.core.lesson_status", pass ? "passed" : "completed");
      SCORM.commit(); SCORM.finish();
    }
    setStatus(pass ? "Passed" : "Completed");
    alert("Training marked complete.");
  });

  // Init SCORM
  var ok=SCORM.init();
  if(ok){
    setStatus("In progress");
    started=true;
    var loc=SCORM.get("cmi.core.lesson_location");
    var n=Number(loc);
    if(!isNaN(n) && n>=0 && n<screens.length) show(n);
  } else {
    setStatus("Preview mode");
    show(0);
  }

  renderQuiz();
})();