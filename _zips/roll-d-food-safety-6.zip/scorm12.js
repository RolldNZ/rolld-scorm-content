(function(){
  function findAPI(win){
    var tries=0;
    while(win && tries<500){
      if(win.API && typeof win.API.LMSInitialize==="function") return win.API;
      tries++; win=win.parent;
      if(win===win.parent) break;
    }
    return null;
  }
  function Scorm12(){ this.API=null; this.initialized=false; }
  Scorm12.prototype.init=function(){
    this.API=findAPI(window);
    if(!this.API) return false;
    var ok=this.API.LMSInitialize("");
    this.initialized=(ok==="true");
    var st=this.get("cmi.core.lesson_status");
    if(!st || st==="not attempted"){ this.set("cmi.core.lesson_status","incomplete"); this.commit(); }
    return this.initialized;
  };
  Scorm12.prototype.get=function(k){ if(!this.API) return ""; return this.API.LMSGetValue(k)||""; };
  Scorm12.prototype.set=function(k,v){ if(!this.API) return false; return this.API.LMSSetValue(k,String(v))==="true"; };
  Scorm12.prototype.commit=function(){ if(!this.API) return false; return this.API.LMSCommit("")==="true"; };
  Scorm12.prototype.finish=function(){ if(!this.API) return false; return this.API.LMSFinish("")==="true"; };
  window.SCORM=new Scorm12();
})();